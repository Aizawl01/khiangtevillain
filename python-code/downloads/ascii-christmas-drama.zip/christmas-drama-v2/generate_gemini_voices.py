"""Regenerate selected directed Gemini takes using GEMINI_API_KEY from the environment."""
import argparse
import base64
import io
import json
import os
from pathlib import Path
import time
import urllib.error
import urllib.request
import wave


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--line',help='Generate only this cast ID, such as 01_1')
    parser.add_argument('--replace',action='store_true',help='Regenerate existing takes; uses API quota')
    args = parser.parse_args()
    key = os.environ.get('GEMINI_API_KEY') or os.environ.get('GOOGLE_API_KEY')
    if not key:
        parser.error('Set GEMINI_API_KEY in your environment. Never paste it into this script or cast.json.')
    root = Path(__file__).resolve().parent
    cast = json.loads((root/'cast_gemini.json').read_text(encoding='utf-8'))
    if args.line:
        cast = [line for line in cast if line['id']==args.line]
        if not cast:
            parser.error('Unknown line ID')
    folder = root/'gemini-takes';folder.mkdir(exist_ok=True)
    for line in cast:
        target = folder/f"{line['id']}.wav"
        if target.is_file() and not args.replace:
            print(f"Keeping approved take {line['id']}")
            continue
        payload = dict(model='gemini-3.8-flash-tts',
                       input=[dict(type='user_input',content=[dict(type='text',text=line['text'],
                       annotations=[dict(type='speech_metadata',style=line['style'])])])],
                       response_format=dict(type='audio',mime_type='audio/wav'),
                       generation_config=dict(speech_config=[dict(voice=line['voice'])]),store=False)
        request = urllib.request.Request('https://generativelanguage.googleapis.com/v1beta/interactions',
                    data=json.dumps(payload).encode(),method='POST',
                    headers={'x-goog-api-key':key,'Content-Type':'application/json'})
        for attempt in range(4):
            try:
                with urllib.request.urlopen(request,timeout=120) as response:
                    result = json.load(response)
                break
            except urllib.error.HTTPError as error:
                if error.code==429 and attempt<3:
                    print('Google rate limit; waiting before retrying.',flush=True)
                    time.sleep(25)
                    continue
                raise RuntimeError(f'Google speech request failed (HTTP {error.code}); no fallback voice was substituted.') from None
        if result.get('status')!='completed':
            raise RuntimeError('Google did not complete the requested take')
        blocks = [part for step in result.get('steps',[]) if step.get('type')=='model_output'
                  for part in step.get('content',[]) if part.get('type')=='audio']
        if len(blocks)!=1 or blocks[0].get('mime_type')!='audio/wav':
            raise RuntimeError('Unexpected speech response')
        audio = base64.b64decode(blocks[0]['data'],validate=True)
        with wave.open(io.BytesIO(audio),'rb') as check:
            if check.getnframes()==0 or check.getnchannels()!=1 or check.getframerate()!=24000:
                raise RuntimeError('Expected nonempty 24 kHz mono speech')
        temp = target.with_suffix('.tmp')
        temp.write_bytes(audio)
        temp.replace(target)
        print(f"Saved {line['id']} ({line['speaker']})",flush=True)


if __name__=='__main__':
    main()
