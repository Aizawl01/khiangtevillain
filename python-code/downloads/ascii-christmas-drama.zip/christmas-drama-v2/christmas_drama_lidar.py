#!/usr/bin/env python3
"""
christmas_drama_lidar.py — Ultra-HD 232x154 3D LiDAR Point-Cloud ASCII Movie
("Christmas Drama" — 100% High-Density Anatomical Mesh & Fresnel Rim-Lit Edition)

Key Realism Upgrades:
1. Ultra-Fine 232x154 High-Definition Grid (35,728 cells) with Fresnel Rim-Lighting ((1 - N·V)^2.2)
   and Atmospheric Depth Attenuation so foreground characters pop in 3D relief against background sets.
2. Sculpted Facial & Cranial Anatomy:
   - Ovoid cranium, zygomatic cheekbones, tapered jaw/chin, recessed orbital eye sockets, brow ridge,
     nose bridge, lips, Marian maphorion veil, keffiyeh headcloth with agal, full biblical beard, or jeweled crown.
3. High-Rising Dorsal Swan/Eagle Archangel Wings (rooted behind the scapulae at z - 0.18, sweeping
   upward above the shoulders before fanning into 22 primary, secondary, and covert feathers).
4. Close-Up Cinema Framing (cam_dist = 2.58, cam_y = 0.92) filling the stage with 1.4x larger figures.
"""

import argparse
import shutil
import sys
import time
import numpy as np

TAU = 2.0 * np.pi
ASCII_RAMP = np.array(list(" .:-=+*#%@"))
CIPHER_CHARS = ".:-=+*#%@"

ARCH, ROBE, WING, GOLD, BEAM, GROUND, STAR, PYRAMID, FLOCK, CHEST, SKIN, HAIR = range(12)

DRAMA_SCENES = [
    (
        1, 0.00, 8.00,
        "SCENE 1/5 · LUKE 1:26-38 · THE ANNUNCIATION IN NAZARETH",
        [
            (0.25, 4.60, "GABRIEL", "Fear not, Mary. You will bear a son, and call his name Jesus."),
            (4.65, 8.00, "MARY",    "I am the servant of the Lord. Let it be as you have spoken."),
        ],
        "SFX: Celestial Portal Laser · 22-Feather Wing Flaps · Holy Spirit Beam",
    ),
    (
        2, 8.00, 16.00,
        "SCENE 2/5 · MATTHEW 1:18-25 · JOSEPH'S DREAM (IMMANUEL)",
        [
            (8.25, 12.80, "ANGEL",  "Joseph, take Mary as your wife. He is Immanuel, God with us."),
            (12.90, 16.00, "JOSEPH", "Mary, an angel spoke in my dream! Let us be wed."),
        ],
        "SFX: Rotating Dream Vortex · Ethereal Harp Arpeggio · Wedding Canopy Chimes",
    ),
    (
        3, 16.00, 24.00,
        "SCENE 3/5 · LUKE 2:1-20 · JESUS IS BORN IN BETHLEHEM",
        [
            (16.25, 20.70, "ANGEL HOST", "Behold, good news! Today in Bethlehem, a Saviour is born!"),
            (20.75, 24.00, "SHEPHERDS",  "Let us hurry to Bethlehem, and see the baby in the manger!"),
        ],
        "SFX: Newborn Crib Glow · Heavenly Host Fanfare · Shepherds & Flock Hurrying",
    ),
    (
        4, 24.00, 32.00,
        "SCENE 4/5 · MATTHEW 2:1-12 · THE THREE WISE MEN & KING HEROD",
        [
            (24.25, 27.60, "KING HEROD", "Where is the newborn King? Go search in Bethlehem!"),
            (27.85, 32.00, "3 WISE MEN", "We saw his star, and bring Gold, Frankincense, and Myrrh."),
        ],
        "SFX: Herod Palace Brass Horn · Guiding Star Lock · Frankincense Smoke & Treasure",
    ),
    (
        5, 32.00, 40.00,
        "SCENE 5/5 · MATTHEW 2:13-23 · ESCAPE TO EGYPT & NAZARETH RETURN",
        [
            (32.25, 36.60, "ANGEL",  "Joseph, rise! Take the child and his mother, and flee to Egypt!"),
            (36.65, 40.00, "JOSEPH", "Herod is gone. We return safely home to Nazareth."),
        ],
        "SFX: Night Desert Wind · 4-Beat Donkey Hoofbeats · Nazareth Sunrise Finale",
    ),
]

SUBTITLE_STYLES = {
    "1": ("cinema_top", "Top Cinema Stage + VO Waveform"),
    "2": ("cipher_mid", "Mid-Screen Cipher Holo-HUD"),
    "3": ("lower_third", "Lower-Third Broadcast Script"),
}
SELECTED_SUBTITLE_STYLE = "cinema_top"


def unit(v):
    v = np.asarray(v, float)
    n = np.linalg.norm(v, axis=-1, keepdims=True)
    return np.where(n > 1e-9, v / np.maximum(n, 1e-9), 0.0)


def fib(n):
    i = np.arange(n) + 0.5
    y = 1 - 2 * i / n
    r = np.sqrt(np.maximum(0.0, 1 - y * y))
    th = np.pi * (3 - np.sqrt(5)) * i
    return np.stack([r * np.cos(th), y, r * np.sin(th)], 1)


class StageCloud:
    def __init__(s):
        s.P, s.N, s.C, s.K, s.SH = [], [], [], [], []

    def add(s, p, n, col, kind, shine=0.5):
        p = np.asarray(p, float)
        if p.ndim == 1:
            p = p[None, :]
        m = len(p)
        if m == 0:
            return
        s.P.append(p)
        s.N.append(unit(np.broadcast_to(np.asarray(n, float), (m, 3))))
        s.C.append(np.broadcast_to(np.asarray(col, float), (m, 3)))
        s.K.append(np.full(m, kind, dtype=np.int32))
        s.SH.append(np.full(m, float(shine), dtype=np.float32))

    def done(s):
        return [np.concatenate(v) for v in (s.P, s.N, s.C, s.K, s.SH)]


# High-density precomputed parametric grids for Ultra-HD 232x154 LiDAR rendering
_SPH_64 = fib(64)
_SPH_140 = fib(140)
_CYL_U, _CYL_A = np.meshgrid(np.linspace(0.0, 1.0, 22), np.linspace(0, TAU, 18, endpoint=False))
_CYL_UF, _CYL_AF = _CYL_U.ravel(), _CYL_A.ravel()
_TUNIC_Y, _TUNIC_A = np.meshgrid(np.linspace(0.05, 0.81, 48), np.linspace(0, TAU, 40, endpoint=False))
_TUNIC_YF, _TUNIC_AF = _TUNIC_Y.ravel(), _TUNIC_A.ravel()
_FLOOR_R, _FLOOR_A = np.meshgrid(np.linspace(0.04, 1.85, 85), np.linspace(0, TAU, 180, endpoint=False))
_FLOOR_RF, _FLOOR_AF = _FLOOR_R.ravel(), _FLOOR_A.ravel()
_PYR_U, _PYR_V = np.meshgrid(np.linspace(0.0, 1.0, 36), np.linspace(-1.0, 1.0, 32))
_PYR_UF, _PYR_VF = _PYR_U.ravel(), _PYR_V.ravel()


def add_limb_segment(q, p0, p1, r0, r1, col, kind=ROBE, shine=0.65):
    p0 = np.asarray(p0, float)
    p1 = np.asarray(p1, float)
    axis = p1 - p0
    length = float(np.linalg.norm(axis))
    if length < 1e-4:
        return
    ez = axis / length
    up = np.array([0.0, 0.0, 1.0]) if abs(ez[2]) < 0.85 else np.array([1.0, 0.0, 0.0])
    ex = unit(np.cross(up, ez))
    ey = unit(np.cross(ez, ex))

    rad = r0 * (1.0 - _CYL_UF) + r1 * _CYL_UF
    ca, sa = np.cos(_CYL_AF), np.sin(_CYL_AF)
    nrm = ex[None, :] * ca[:, None] + ey[None, :] * sa[:, None]
    pts = p0[None, :] + ez[None, :] * (_CYL_UF * length)[:, None] + nrm * rad[:, None]
    q.add(pts, nrm, col, kind, shine=shine)


def add_lidar_floor(q, ripple_phase: float = 0.0, col=(0.14, 0.78, 0.96)):
    yg = -0.03 + 0.010 * np.sin(_FLOOR_RF * 18.0 - ripple_phase)
    pg = np.column_stack([_FLOOR_RF * np.cos(_FLOOR_AF), yg, _FLOOR_RF * np.sin(_FLOOR_AF)])
    is_ring = (np.round(_FLOOR_RF * 34).astype(int) % 4) == 0
    is_ray = (np.round(_FLOOR_AF / TAU * 28).astype(int) % 2) == 0
    shade = np.where(is_ring, 0.88, np.where(is_ray, 0.36, 0.16)) * np.exp(-0.38 * _FLOOR_RF ** 2)
    q.add(pg, [0, 1, 0], shade[:, None] * np.asarray(col), GROUND, shine=0.30)


def add_anatomical_human(
    q, cx, cy, cz, height, robe_col, mantle_col=None,
    is_female=False, has_beard=False, has_veil=False, has_crown=False,
    pose="prayer", walk_phase=0.0, bow_pitch=0.0, speaking_vo=0.0, staff_side=0, facing_x=0.0
):
    """
    Ultra-HD 8-Head Anatomical 3D Humanoid Character with Sculpted Facial Features,
    Collarbone/Chest/Waist/Hip Contours, 10-Fold Catenary Tunic, Draped Outer Mantle,
    Articulated Shoulders/Elbows/Wrists/Fingers, and Sandaled Feet.
    """
    if mantle_col is None:
        mantle_col = tuple(min(1.0, c * 1.22) for c in robe_col)

    H = float(height)
    bob_y = 0.022 * abs(np.sin(walk_phase)) if walk_phase != 0.0 else 0.0
    cy = cy + bob_y
    cb, sb = np.cos(bow_pitch), np.sin(bow_pitch)

    def to_world(lx, ly, lz):
        if abs(bow_pitch) > 1e-3 and ly > 0.48 * H:
            hip_y = 0.48 * H
            dy = ly - hip_y
            ly, lz = hip_y + dy * cb - lz * sb, dy * sb + lz * cb
        if abs(facing_x) > 1e-3:
            cy_a, sy_a = np.cos(facing_x), np.sin(facing_x)
            lx, lz = lx * cy_a + lz * sy_a, -lx * sy_a + lz * cy_a
        return np.array([cx + lx, cy + ly, cz + lz])

    # 1. Sculpted 8-Head Anatomical Torso & 10-Fold Catenary Tunic (0.05 H to 0.81 H)
    sh_half = (0.106 if is_female else 0.132) * H
    chest_r = (0.088 if is_female else 0.104) * H
    waist_r = (0.068 if is_female else 0.080) * H
    hip_r = (0.096 if is_female else 0.092) * H
    hem_r = 0.134 * H

    yn = _TUNIC_YF
    profile_r = np.where(
        yn > 0.68,
        chest_r + (sh_half * 0.90 - chest_r) * ((yn - 0.68) / 0.13),
        np.where(
            yn > 0.58,
            waist_r + (chest_r - waist_r) * ((yn - 0.58) / 0.10),
            np.where(
                yn > 0.46,
                hip_r + (waist_r - hip_r) * ((yn - 0.46) / 0.12),
                hem_r + (hip_r - hem_r) * (yn / 0.46),
            ),
        ),
    )
    # 10 deep catenary vertical folds + subtle walking stride ripple in lower hem
    fold_amp = 0.15 * (1.0 - 0.60 * yn)
    r_pleat = profile_r * (1.0 + fold_amp * np.cos(10.0 * _TUNIC_AF))
    tx = r_pleat * np.cos(_TUNIC_AF)
    ty = yn * H
    # Realistic human torso depth (flatter front-to-back than side-to-side, plus feminina/pectoral contour)
    chest_bulge = 0.018 * H * np.exp(-((yn - 0.71) / 0.055) ** 2) * np.maximum(0.0, np.sin(_TUNIC_AF))
    tz = r_pleat * np.sin(_TUNIC_AF) * 0.72 + chest_bulge
    if walk_phase != 0.0:
        tz += 0.055 * H * (1.0 - yn / 0.81) * np.sin(walk_phase) * np.cos(_TUNIC_AF)

    if abs(bow_pitch) > 1e-3:
        hip_y = 0.48 * H
        upper = ty > hip_y
        dy = ty[upper] - hip_y
        ty[upper], tz[upper] = hip_y + dy * cb - tz[upper] * sb, dy * sb + tz[upper] * cb

    if abs(facing_x) > 1e-3:
        cy_a, sy_a = np.cos(facing_x), np.sin(facing_x)
        tx, tz = tx * cy_a + tz * sy_a, -tx * sy_a + tz * cy_a

    tnrm = np.column_stack([
        np.cos(_TUNIC_AF) - 0.40 * np.sin(10.0 * _TUNIC_AF) * np.sin(_TUNIC_AF),
        np.full_like(_TUNIC_AF, 0.25),
        np.sin(_TUNIC_AF) + 0.40 * np.sin(10.0 * _TUNIC_AF) * np.cos(_TUNIC_AF),
    ])
    # Golden Collar Trim, Waist Girdle Belt (at y = 0.60 H), Hem Border, and Diagonal Mantle Sash
    is_trim = (
        (np.abs(yn - 0.60) < 0.024)
        | (yn < 0.085)
        | (yn > 0.785)
        | (np.abs((yn - 0.46) - 0.19 * np.sin(_TUNIC_AF)) < 0.048)
    )
    q.add(np.column_stack([cx + tx[~is_trim], cy + ty[~is_trim], cz + tz[~is_trim]]), tnrm[~is_trim], robe_col, ROBE, shine=0.62)
    q.add(np.column_stack([cx + tx[is_trim], cy + ty[is_trim], cz + tz[is_trim]]), tnrm[is_trim], mantle_col, GOLD, shine=0.88)

    # 2. Cervical Neck & Sculpted 3D Human Head + Facial Features (0.81 H -> 1.00 H)
    neck_p0 = to_world(0.0, 0.805 * H, 0.0)
    neck_p1 = to_world(0.0, 0.875 * H, 0.012 * H)
    add_limb_segment(q, neck_p0, neck_p1, 0.030 * H, 0.026 * H, (0.96, 0.88, 0.80), SKIN, shine=0.70)

    head_c = to_world(0.0, 0.935 * H, 0.018 * H)
    # Sculpted cranium + tapered jaw/chin
    jaw_taper = np.where(_SPH_140[:, 1] < 0, 1.0 + 0.28 * _SPH_140[:, 1], 1.0)
    hx_pts = _SPH_140[:, 0] * 0.052 * H * jaw_taper
    hy_pts = _SPH_140[:, 1] * 0.065 * H
    hz_pts = _SPH_140[:, 2] * 0.058 * H
    # Carve subtle orbital eye sockets so the face has unmistakable eyes, brow ridge & cheekbones!
    eye_mask = (
        (np.abs( np.abs(_SPH_140[:, 0]) - 0.36 ) < 0.18)
        & (np.abs(_SPH_140[:, 1] - 0.10) < 0.16)
        & (_SPH_140[:, 2] > 0.55)
    )
    skull_world = np.column_stack([head_c[0] + hx_pts, head_c[1] + hy_pts, head_c[2] + hz_pts])
    q.add(skull_world[~eye_mask], _SPH_140[~eye_mask], (0.98, 0.92, 0.85), SKIN, shine=0.78)
    # Prominent Nose Bridge, Brow Arch & Chin Highlight
    for ny_f, nz_f in [(0.018, 0.062), (0.006, 0.066), (-0.006, 0.068), (-0.032, 0.058)]:
        p_feat = to_world(0.0, (0.935 + ny_f) * H, (0.018 + nz_f) * H)
        q.add(p_feat, [0, 0.2, 1.0], (1.0, 0.98, 0.92), SKIN, shine=0.92)

    # Full Sculpted Biblical Beard & Mustache
    if has_beard:
        ba, by = np.meshgrid(np.linspace(-0.78 * np.pi, -0.22 * np.pi, 22), np.linspace(-0.072 * H, -0.012 * H, 14))
        baf, byf = ba.ravel(), by.ravel()
        br = 0.048 * H * (1.0 + 0.45 * (byf / (0.072 * H)))
        bx_b = br * np.cos(baf)
        bz_b = 0.022 * H - br * np.sin(baf)
        if abs(facing_x) > 1e-3:
            cy_a, sy_a = np.cos(facing_x), np.sin(facing_x)
            bx_b, bz_b = bx_b * cy_a + bz_b * sy_a, -bx_b * sy_a + bz_b * cy_a
        q.add(np.column_stack([head_c[0] + bx_b, head_c[1] + byf, head_c[2] + bz_b]), [0, -0.3, 0.95], (0.72, 0.64, 0.54), HAIR, shine=0.50)

    # Flowing Marian Veil (Maphorion) or Biblical Keffiyeh Headcloth framing the head & shoulders
    if has_veil:
        vu, va = np.meshgrid(np.linspace(0.0, 1.0, 28), np.linspace(0.12 * np.pi, 0.88 * np.pi, 28))
        vuf, vaf = vu.ravel(), va.ravel()
        vr = (0.056 + 0.072 * vuf) * H
        vx = vr * np.cos(vaf)
        vy = (0.065 - 0.24 * vuf) * H
        vz = -0.012 * H - vr * np.sin(vaf) * 0.72
        if abs(facing_x) > 1e-3:
            cy_a, sy_a = np.cos(facing_x), np.sin(facing_x)
            vx, vz = vx * cy_a + vz * sy_a, -vx * sy_a + vz * cy_a
        q.add(np.column_stack([head_c[0] + vx, head_c[1] + vy, head_c[2] + vz]), [0, 0.4, 0.9], mantle_col, ROBE, shine=0.76)

    # 3. Articulated Upper Limbs: Deltoid Shoulders -> Humerus -> Elbows -> Forearms -> Sculpted Hands
    for side in (-1.0, 1.0):
        sh_p = to_world(side * sh_half, 0.785 * H, 0.0)
        # Deltoid shoulder cap sphere
        q.add(_SPH_64 * (0.036 * H) + sh_p, _SPH_64, mantle_col, ROBE, shine=0.72)

        if pose == "herald" and side == 1.0:
            el_p = to_world(side * (sh_half + 0.085 * H), 0.85 * H, 0.09 * H)
            wr_p = to_world(side * (sh_half + 0.145 * H), 0.98 * H, 0.16 * H)
        elif pose == "prayer":
            el_p = to_world(side * (sh_half + 0.035 * H), 0.63 * H, 0.065 * H)
            wr_p = to_world(side * 0.020 * H, 0.715 * H, 0.125 * H)
        elif staff_side == side:
            el_p = to_world(side * (sh_half + 0.035 * H), 0.66 * H, 0.075 * H)
            wr_p = to_world(side * (sh_half * 1.18), 0.725 * H, 0.145 * H)
        else:
            arm_sw = 0.095 * H * np.sin(walk_phase + (np.pi if side < 0 else 0.0)) if walk_phase != 0 else 0.035 * H
            el_p = to_world(side * (sh_half + 0.028 * H), 0.62 * H, arm_sw * 0.5)
            wr_p = to_world(side * (sh_half + 0.038 * H), 0.49 * H, arm_sw + 0.045 * H)

        add_limb_segment(q, sh_p, el_p, 0.035 * H, 0.029 * H, robe_col, ROBE, shine=0.65)
        add_limb_segment(q, el_p, wr_p, 0.029 * H, 0.022 * H, mantle_col, ROBE, shine=0.72)
        q.add(_SPH_64 * (0.024 * H) + wr_p, _SPH_64, (0.98, 0.90, 0.82), SKIN, shine=0.80)

    # 4. Articulated Lower Limbs: Knees -> Calves -> Ankles -> Sandaled Feet
    for side in (-1.0, 1.0):
        leg_ph = walk_phase + (0.0 if side < 0 else np.pi)
        stride_z = 0.115 * H * np.sin(leg_ph) if walk_phase != 0.0 else 0.0
        lift_y = 0.048 * H * max(0.0, np.cos(leg_ph)) if walk_phase != 0.0 else 0.0

        knee_p = np.array([cx + side * 0.050 * H, cy + 0.265 * H + lift_y * 0.5, cz + stride_z * 0.55])
        ank_p = np.array([cx + side * 0.050 * H, cy + 0.038 * H + lift_y, cz + stride_z])
        toe_p = np.array([cx + side * 0.052 * H, cy + 0.018 * H + lift_y, cz + stride_z + 0.072 * H])

        add_limb_segment(q, knee_p, ank_p, 0.032 * H, 0.023 * H, (0.92, 0.84, 0.76), SKIN, shine=0.65)
        add_limb_segment(q, ank_p, toe_p, 0.024 * H, 0.019 * H, (0.92, 0.72, 0.36), GOLD, shine=0.80)

    # 5. Speaking Voice-Over Halo Ring behind the head (never obscuring the face)
    if speaking_vo > 0.08:
        ha = np.linspace(0, TAU, 48, endpoint=False)
        hr = 0.092 * H * (1.22 + 0.45 * speaking_vo)
        h_pts = np.column_stack([head_c[0] + hr * np.cos(ha), head_c[1] + hr * np.sin(ha), np.full_like(ha, head_c[2] - 0.045 * H)])
        q.add(h_pts, [0, 0, 1], (0.45, 1.00, 1.00), STAR, shine=1.0)

    # 6. Ornate Royal Crown
    if has_crown:
        ca = np.linspace(0, TAU, 36, endpoint=False)
        cr_r = 0.054 * H
        cr_y = head_c[1] + 0.050 * H + 0.026 * H * np.abs(np.sin(ca * 5))
        q.add(np.column_stack([head_c[0] + cr_r * np.cos(ca), cr_y, head_c[2] + cr_r * np.sin(ca)]), [0, 1, 0], (1.0, 0.88, 0.28), GOLD, shine=0.96)

    # 7. Shepherd's Crook / Herald Staff
    if staff_side != 0:
        sx = cx + staff_side * (sh_half * 1.22)
        sz = cz + 0.14 * H
        sy = np.linspace(cy, cy + H * 1.15, 60)
        q.add(np.column_stack([np.full_like(sy, sx), sy, np.full_like(sy, sz)]), [0, 0, 1], (1.0, 0.86, 0.35), GOLD, shine=0.90)
        crook_a = np.linspace(0, np.pi * 1.25, 28)
        q.add(
            np.column_stack([sx - staff_side * 0.045 * H + 0.045 * H * np.cos(crook_a), cy + H * 1.15 + 0.045 * H * np.sin(crook_a), np.full_like(crook_a, sz)]),
            [0, 0, 1],
            (1.0, 0.86, 0.35),
            GOLD,
            shine=0.94,
        )


def add_anatomical_avian_wings(q, cx, cy, cz, span, height, flap_angle, col=(0.55, 1.00, 1.00)):
    """
    High-Rising Dorsal Swan/Eagle Archangel Wings:
    - Rooted behind the shoulder blades (cz - 0.14) so they NEVER block the angel's face or torso!
    - Sweeps high upward (+0.38*height at the carpal wrist arch) before fanning outward into
      18 Primary & Secondary Flight Feathers (Remiges) + 10 Upper Covert Feathers.
    """
    cf, sf = np.cos(flap_angle), np.sin(flap_angle)
    z_back = cz - 0.14

    for sgn in (-1.0, 1.0):
        # High-rising classical archangel wing bone curve (Shoulder -> High Carpal Arch -> Sweeping Tip)
        sh_p = np.array([cx + sgn * 0.08, cy, z_back])
        el_p = np.array([cx + sgn * (0.30 * span) * cf, cy + 0.28 * height + 0.10 * span * sf, z_back - 0.12 * span * sf])
        wr_p = np.array([cx + sgn * (0.64 * span) * cf, cy + 0.42 * height + 0.20 * span * sf, z_back - 0.25 * span * sf])
        tip_p = np.array([cx + sgn * span * cf, cy + 0.22 * height + 0.28 * span * sf, z_back - 0.38 * span * sf])

        add_limb_segment(q, sh_p, el_p, 0.024, 0.020, (0.90, 1.0, 1.0), WING, shine=0.98)
        add_limb_segment(q, el_p, wr_p, 0.020, 0.016, (0.90, 1.0, 1.0), WING, shine=0.98)
        add_limb_segment(q, wr_p, tip_p, 0.016, 0.009, (0.90, 1.0, 1.0), WING, shine=0.98)

        # 18 Individual Radiating Flight Feathers fanning outward & downward from the dorsal arch
        u_f = np.linspace(0.0, 1.0, 26)
        for f_idx in range(18):
            frac = f_idx / 17.0
            if frac < 0.35:
                w_b = frac / 0.35
                root = sh_p * (1 - w_b) + el_p * w_b
            elif frac < 0.72:
                w_b = (frac - 0.35) / 0.37
                root = el_p * (1 - w_b) + wr_p * w_b
            else:
                w_b = (frac - 0.72) / 0.28
                root = wr_p * (1 - w_b) + tip_p * w_b

            # Outer primaries fan outward (-12° to -55°), inner secondaries drape gracefully beside the legs
            fan_pitch = np.deg2rad(-68.0 + 56.0 * (frac ** 0.95))
            f_len = height * (0.48 + 0.46 * np.sin(frac * np.pi * 0.88))
            aero_bend = 0.055 * (u_f ** 2) * sf

            # Offset inner feathers outward (+sgn * 0.10) so they frame the body cleanly without crossing the face
            fx = root[0] + sgn * (0.06 + u_f * f_len * np.cos(fan_pitch) * cf)
            fy = root[1] + u_f * f_len * np.sin(fan_pitch) + aero_bend
            fz = root[2] - u_f * f_len * 0.22 * sf - 0.02 * u_f
            for dv in (-0.010, 0.0, 0.010):
                q.add(
                    np.column_stack([fx + sgn * dv, fy, fz]),
                    [sgn * 0.35, 0.45, 0.82],
                    col if dv == 0.0 else (col[0] * 0.80, col[1] * 0.92, col[2]),
                    WING,
                    shine=0.95,
                )


def add_anatomical_donkey(q, dx, dy, dz, scale=1.0, walk_phase=0.0):
    S = float(scale)
    bob = 0.018 * S * abs(np.sin(walk_phase * 2.0))
    by = dy + 0.36 * S + bob

    u_t, a_t = np.meshgrid(np.linspace(-0.26 * S, 0.26 * S, 32), np.linspace(0, TAU, 22, endpoint=False))
    utf, atf = u_t.ravel(), a_t.ravel()
    ry_t = S * (0.115 + 0.020 * np.cos((utf / (0.26 * S)) * np.pi) + 0.012 * (utf / (0.26 * S)))
    rz_t = S * (0.095 + 0.015 * np.cos((utf / (0.26 * S)) * np.pi))
    tx = dx + utf
    ty = by + ry_t * np.sin(atf)
    tz = dz + rz_t * np.cos(atf)
    tnrm = np.column_stack([np.zeros_like(atf), np.sin(atf), np.cos(atf)])
    q.add(np.column_stack([tx, ty, tz]), tnrm, (0.52, 0.84, 0.96), ARCH, shine=0.58)

    neck_p0 = np.array([dx + 0.20 * S, by + 0.04 * S, dz])
    neck_p1 = np.array([dx + 0.34 * S, by + 0.22 * S + 0.015 * S * np.sin(walk_phase), dz])
    add_limb_segment(q, neck_p0, neck_p1, 0.068 * S, 0.048 * S, (0.58, 0.88, 0.98), ARCH, shine=0.62)

    muzzle_p = neck_p1 + np.array([0.11 * S, -0.05 * S, 0.0])
    add_limb_segment(q, neck_p1, muzzle_p, 0.048 * S, 0.028 * S, (0.72, 0.94, 1.00), ARCH, shine=0.72)

    for ez_s in (-1.0, 1.0):
        ear_base = neck_p1 + np.array([-0.01 * S, 0.03 * S, ez_s * 0.032 * S])
        ear_tip = ear_base + np.array([0.02 * S, 0.14 * S, ez_s * 0.035 * S])
        add_limb_segment(q, ear_base, ear_tip, 0.018 * S, 0.007 * S, (0.85, 0.98, 1.00), GOLD, shine=0.85)

    tail_p0 = np.array([dx - 0.26 * S, by + 0.03 * S, dz])
    tail_p1 = np.array([dx - 0.36 * S, by - 0.14 * S, dz + 0.04 * S * np.sin(walk_phase)])
    add_limb_segment(q, tail_p0, tail_p1, 0.018 * S, 0.010 * S, (0.42, 0.76, 0.90), ARCH, shine=0.50)

    leg_configs = [
        (-0.20 * S, -0.06 * S, 0.00 * TAU),
        ( 0.19 * S, -0.06 * S, 0.25 * TAU),
        (-0.20 * S,  0.06 * S, 0.50 * TAU),
        ( 0.19 * S,  0.06 * S, 0.75 * TAU),
    ]
    for lx_off, lz_off, ph_off in leg_configs:
        ph = walk_phase + ph_off
        hip_p = np.array([dx + lx_off, by - 0.04 * S, dz + lz_off])
        swing = 0.09 * S * np.sin(ph)
        lift = 0.06 * S * max(0.0, np.cos(ph))
        knee_p = np.array([dx + lx_off + swing * 0.45 + 0.02 * S * (lift / (0.06 * S + 1e-5)), dy + 0.17 * S + lift * 0.6, dz + lz_off])
        hoof_p = np.array([dx + lx_off + swing, dy + 0.01 + lift, dz + lz_off])
        add_limb_segment(q, hip_p, knee_p, 0.032 * S, 0.022 * S, (0.48, 0.80, 0.94), ARCH, shine=0.58)
        add_limb_segment(q, knee_p, hoof_p, 0.022 * S, 0.018 * S, (0.90, 0.76, 0.36), GOLD, shine=0.78)


def add_anatomical_sheep(q, sx, sy, sz, scale=1.0, walk_phase=0.0):
    S = float(scale)
    for ox, oy, oz, r_lobe in [(-0.05, 0.12, 0.0, 0.068), (0.0, 0.13, 0.0, 0.074), (0.05, 0.12, 0.0, 0.066)]:
        q.add(_SPH_64 * (r_lobe * S) + np.array([sx + ox * S, sy + oy * S, sz + oz * S]), _SPH_64, (0.92, 0.97, 1.00), FLOCK, shine=0.65)
    head_p = np.array([sx + 0.11 * S, sy + 0.16 * S, sz])
    q.add(_SPH_64 * np.array([0.042 * S, 0.034 * S, 0.032 * S]) + head_p, _SPH_64, (0.75, 0.88, 0.96), ARCH, shine=0.72)
    for lx_s in (-0.05 * S, 0.05 * S):
        for lz_s in (-0.03 * S, 0.03 * S):
            sw = 0.025 * S * np.sin(walk_phase + lx_s * 20) if walk_phase != 0 else 0.0
            add_limb_segment(q, [sx + lx_s, sy + 0.10 * S, sz + lz_s], [sx + lx_s + sw, sy, sz + lz_s], 0.012 * S, 0.009 * S, (0.65, 0.82, 0.92), ARCH, shine=0.55)


def build_scene_geometry(t: float, vo_val: float, sfx_val: float, forced_scene: int = 0, active_speaker=None):
    if 1 <= forced_scene <= 5:
        sc_idx = forced_scene
        local_t = (t % 8.0) * (5.0 / 8.0)
    else:
        t_clamped = max(0.0, min(39.999, t % 40.0))
        sc_idx = int(t_clamped // 8.0) + 1
        local_t = (t_clamped - (sc_idx - 1) * 8.0) * (5.0 / 8.0)

    u_prog = np.clip(local_t / 5.0, 0.0, 1.0)
    q = StageCloud()
    add_lidar_floor(q, ripple_phase=t * 4.2)

    # =========================================================================
    # SCENE 1 (0-8s): THE ANNUNCIATION IN NAZARETH (Luke 1:26-38)
    # =========================================================================
    if sc_idx == 1:
        # Background Nazareth Colonnade pushed back to z = -0.65 so foreground characters have 100% clean separation
        col_xs = (-1.18, -0.40, 0.40, 1.18)
        py_c, pa_c = np.meshgrid(np.linspace(0.0, 1.55, 42), np.linspace(0, TAU, 18, endpoint=False))
        for cx_p in col_xs:
            pts_c = np.column_stack([cx_p + 0.065 * np.cos(pa_c.ravel()), py_c.ravel(), -0.65 + 0.065 * np.sin(pa_c.ravel())])
            nrm_c = np.column_stack([np.cos(pa_c.ravel()), np.zeros(pa_c.size), np.sin(pa_c.ravel())])
            q.add(pts_c, nrm_c, (0.16, 0.52, 0.72), ARCH, shine=0.35)

        for a_x0, a_x1 in [(-1.18, -0.40), (-0.40, 0.40), (0.40, 1.18)]:
            mid_x = 0.5 * (a_x0 + a_x1)
            rad_a = 0.5 * (a_x1 - a_x0)
            ang_a, z_a = np.meshgrid(np.linspace(0, np.pi, 36), np.linspace(-0.70, -0.60, 6))
            ax_f = mid_x + rad_a * np.cos(ang_a.ravel())
            ay_f = 1.55 + rad_a * 0.82 * np.sin(ang_a.ravel())
            q.add(np.column_stack([ax_f, ay_f, z_a.ravel()]), [0, 0.4, 0.9], (0.22, 0.64, 0.84), ARCH, shine=0.45)

        gab_y = 0.08 + 0.35 * np.exp(-local_t * 1.3) + 0.03 * np.sin(t * 3.5)
        flap = 0.38 * np.sin(t * 6.0)
        gab_vo = (vo_val if active_speaker == "GABRIEL" else 0.0) if active_speaker is not None else (vo_val if local_t < 2.90 else 0.0)
        add_anatomical_human(
            q, -0.52, gab_y, 0.42, height=1.24, robe_col=(0.38, 0.96, 1.00), mantle_col=(0.92, 1.00, 1.00),
            pose="herald", speaking_vo=gab_vo, staff_side=-1, facing_x=0.28
        )
        add_anatomical_avian_wings(q, -0.52, gab_y + 0.88, 0.42, span=0.76, height=0.72, flap_angle=flap, col=(0.65, 1.00, 1.00))

        mary_bow = 0.26 * np.clip((local_t - 2.5) / 1.2, 0.0, 1.0)
        mary_vo = (vo_val if active_speaker == "MARY" else 0.0) if active_speaker is not None else (vo_val if local_t >= 2.90 else 0.0)
        add_anatomical_human(
            q, 0.52, 0.0, 0.44, height=1.08, robe_col=(0.18, 0.82, 1.00), mantle_col=(0.95, 0.98, 1.00),
            is_female=True, has_veil=True, pose="prayer", bow_pitch=mary_bow, speaking_vo=mary_vo, facing_x=-0.28
        )

        beam_reach = np.clip((local_t - 0.3) / 1.4, 0.0, 1.0)
        bs, ba = np.meshgrid(np.linspace(0.0, beam_reach, 48), np.linspace(0, TAU, 16, endpoint=False))
        bsf, baf = bs.ravel(), ba.ravel()
        br = 0.025 + 0.065 * bsf
        bx = 0.52 * bsf + br * np.cos(baf)
        by = 2.15 * (1.0 - bsf) + 1.02 * bsf
        bz = 0.44 * bsf + br * np.sin(baf)
        q.add(np.column_stack([bx, by, bz]), [0, 0, 1], (1.00, 0.92, 0.42), BEAM, shine=1.0)
        q.add(_SPH_140 * 0.10 + np.array([0.0, 2.18, 0.0]), _SPH_140, (0.75, 1.0, 1.0), STAR, shine=1.0)

    # =========================================================================
    # SCENE 2 (8-16s): JOSEPH'S DREAM ("IMMANUEL") & WEDDING CANOPY (Matt 1:18-25)
    # =========================================================================
    elif sc_idx == 2:
        hx_u = np.linspace(0.0, 1.0, 260)
        for strand in (0.0, np.pi):
            ang = hx_u * TAU * 3.0 - t * 3.2 + strand
            rad = 0.18 + 0.26 * hx_u
            hx = -0.60 + rad * np.cos(ang)
            hy = 0.06 + 1.95 * hx_u
            hz = -0.25 + rad * np.sin(ang)
            q.add(np.column_stack([hx, hy, hz]), [0, 1, 0], (0.32, 0.92, 1.00), BEAM, shine=0.90)

        ang_vo = (vo_val if active_speaker in ("ANGEL", "ANGEL HOST") else 0.0) if active_speaker is not None else (vo_val if local_t < 3.00 else 0.0)
        add_anatomical_human(
            q, -0.60, 1.02 + 0.04 * np.sin(t * 4.0), 0.12, height=1.02, robe_col=(0.55, 1.00, 1.00),
            pose="herald", speaking_vo=ang_vo
        )
        add_anatomical_avian_wings(q, -0.60, 1.76, 0.12, span=0.64, height=0.58, flap_angle=0.38 * np.sin(t * 6.0), col=(0.65, 1.00, 1.00))

        for px_w in (0.06, 0.94):
            for pz_w in (-0.10, 0.48):
                py_w = np.linspace(0.0, 1.48, 40)
                q.add(np.column_stack([np.full_like(py_w, px_w), py_w, np.full_like(py_w, pz_w)]), [0, 0, 1], (0.85, 0.66, 0.28), ARCH, shine=0.50)
        cx_g, cz_g = np.meshgrid(np.linspace(0.02, 0.98, 38), np.linspace(-0.14, 0.52, 18))
        cy_g = 1.48 + 0.20 * np.cos((cx_g - 0.50) * 3.1) * np.cos((cz_g - 0.19) * 3.1)
        q.add(np.column_stack([cx_g.ravel(), cy_g.ravel(), cz_g.ravel()]), [0, 1, 0], (1.00, 0.86, 0.32), GOLD, shine=0.85)

        walk_w = np.clip((local_t - 2.4) / 1.6, 0.0, 1.0)
        jos_x = -0.54 * (1.0 - walk_w) + 0.30 * walk_w
        jos_z = 0.46 * (1.0 - walk_w) + 0.38 * walk_w
        jos_bow = -0.38 * (1.0 - walk_w)
        jos_walk = t * 9.0 if (0.02 < walk_w < 0.98) else 0.0
        jos_vo = (vo_val if active_speaker == "JOSEPH" else 0.0) if active_speaker is not None else (vo_val if local_t >= 3.00 else 0.0)
        add_anatomical_human(
            q, jos_x, 0.0, jos_z, height=1.16, robe_col=(0.98, 0.74, 0.30), mantle_col=(1.0, 0.88, 0.48),
            has_beard=True, has_veil=True, pose="walk" if jos_walk != 0 else "prayer", bow_pitch=jos_bow, walk_phase=jos_walk, speaking_vo=jos_vo, facing_x=0.22
        )
        add_anatomical_human(
            q, 0.68, 0.0, 0.38, height=1.04, robe_col=(0.18, 0.85, 1.00), mantle_col=(0.95, 0.98, 1.00),
            is_female=True, has_veil=True, pose="prayer", facing_x=-0.22
        )

    # =========================================================================
    # SCENE 3 (16-24s): JESUS IS BORN IN BETHLEHEM & THE SHEPHERDS (Luke 2:1-20)
    # =========================================================================
    elif sc_idx == 3:
        st_x, st_z = 0.36, 0.15
        for px_s in (-0.64, 0.64):
            for pz_s in (-0.32, 0.18):
                py_s = np.linspace(0.0, 1.22, 46)
                for dx_s in (-0.018, 0.0, 0.018):
                    q.add(np.column_stack([np.full_like(py_s, st_x + px_s + dx_s), py_s, np.full_like(py_s, st_z + pz_s)]), [0, 0, 1], (0.82, 0.60, 0.25), ARCH, shine=0.45)
        rx_s, rz_s = np.meshgrid(np.linspace(-0.74, 0.74, 62), np.linspace(-0.35, 0.22, 20))
        rxf, rzf = rx_s.ravel(), rz_s.ravel()
        ryf = 1.86 - 0.86 * np.abs(rxf)
        rnrm = np.column_stack([np.sign(rxf) * 0.6, np.full_like(rxf, 0.8), np.full_like(rxf, 0.25)])
        q.add(np.column_stack([st_x + rxf, ryf, st_z + rzf]), rnrm, (0.96, 0.76, 0.30), GOLD, shine=0.62)

        # Glowing Manger Crib & Swaddled Infant Jesus in Foreground (z = +0.42)
        for leg_s in (-1.0, 1.0):
            ly_m = np.linspace(0.0, 0.30, 26)
            lx_m = st_x + leg_s * (ly_m - 0.15) * 1.25
            q.add(np.column_stack([lx_m, ly_m, np.full_like(ly_m, 0.42)]), [0, 0, 1], (0.88, 0.62, 0.26), ARCH, shine=0.55)
        cr_x, cr_z = np.meshgrid(np.linspace(-0.20, 0.20, 28), np.linspace(-0.10, 0.10, 14))
        cr_y = 0.24 + 0.38 * np.abs(cr_x.ravel())
        q.add(np.column_stack([st_x + cr_x.ravel(), cr_y, 0.42 + cr_z.ravel()]), [0, 0.8, 0.6], (1.0, 0.86, 0.38), GOLD, shine=0.82)
        q.add(_SPH_140 * np.array([0.11, 0.065, 0.065]) + np.array([st_x - 0.02, 0.36, 0.44]), _SPH_140, (1.0, 0.98, 0.82), STAR, shine=1.0)
        q.add(_SPH_64 * 0.052 + np.array([st_x + 0.08, 0.38, 0.45]), _SPH_64, (1.0, 0.96, 0.88), STAR, shine=1.0)

        add_anatomical_human(
            q, st_x - 0.36, 0.0, 0.38, height=0.98, robe_col=(0.18, 0.85, 1.00),
            is_female=True, has_veil=True, pose="prayer", bow_pitch=0.22, facing_x=0.30
        )
        add_anatomical_human(
            q, st_x + 0.38, 0.0, 0.38, height=1.14, robe_col=(0.98, 0.72, 0.32),
            has_beard=True, has_veil=True, pose="prayer", staff_side=1, facing_x=-0.30
        )

        ang_vo = (vo_val if active_speaker in ("ANGEL", "ANGEL HOST") else 0.0) if active_speaker is not None else (vo_val if local_t < 2.85 else 0.0)
        add_anatomical_human(q, -0.52, 1.32, 0.05, height=0.84, robe_col=(0.65, 1.00, 1.00), pose="herald", speaking_vo=ang_vo)
        add_anatomical_avian_wings(q, -0.52, 1.92, 0.05, span=0.58, height=0.52, flap_angle=0.40 * np.sin(t * 6.5), col=(0.55, 1.00, 1.00))

        sh_move = 0.28 * np.clip((local_t - 2.2) / 2.5, 0.0, 1.0)
        sh_walk = t * 10.0 if local_t > 2.2 else 0.0
        sh_vo = (vo_val if active_speaker == "SHEPHERDS" else 0.0) if active_speaker is not None else (vo_val if local_t >= 2.85 else 0.0)
        add_anatomical_human(
            q, -0.96 + sh_move, 0.0, 0.42, height=1.08, robe_col=(0.38, 0.95, 0.72),
            has_beard=True, has_veil=True, walk_phase=sh_walk, speaking_vo=sh_vo, staff_side=-1, facing_x=0.32
        )
        add_anatomical_human(
            q, -0.58 + sh_move, 0.0, 0.48, height=1.00, robe_col=(0.32, 0.88, 0.98),
            has_beard=True, walk_phase=sh_walk + 1.5, speaking_vo=sh_vo, staff_side=-1, facing_x=0.32
        )
        for sx_f, sz_f in [(-1.05 + sh_move, 0.68), (-0.72 + sh_move, 0.72)]:
            add_anatomical_sheep(q, sx_f, 0.0, sz_f, scale=1.1, walk_phase=sh_walk)

    # =========================================================================
    # SCENE 4 (24-32s): THREE WISE MEN & KING HEROD (Matthew 2:1-12)
    # =========================================================================
    elif sc_idx == 4:
        herod_vo = (vo_val if active_speaker == "KING HEROD" else 0.0) if active_speaker is not None else (vo_val if local_t < 2.35 else 0.0)
        add_anatomical_human(
            q, -0.98, 0.08, 0.28, height=1.14, robe_col=(0.98, 0.18, 0.38), mantle_col=(1.0, 0.85, 0.28),
            has_beard=True, has_crown=True, pose="herald", speaking_vo=herod_vo, staff_side=-1, facing_x=0.30
        )
        ang_h = np.linspace(0, np.pi, 48)
        q.add(np.column_stack([0.70 + 0.48 * np.cos(ang_h), 1.15 + 0.42 * np.sin(ang_h), np.full_like(ang_h, -0.25)]), [0, 0, 1], (0.85, 0.68, 0.28), ARCH, shine=0.5)
        add_anatomical_human(
            q, 0.72, 0.0, 0.36, height=1.02, robe_col=(0.18, 0.85, 1.00),
            is_female=True, has_veil=True, pose="prayer", facing_x=-0.30
        )
        q.add(_SPH_64 * 0.088 + np.array([0.62, 0.56, 0.46]), _SPH_64, (1.0, 0.98, 0.75), STAR, shine=1.0)

        star_w = np.clip(local_t / 2.6, 0.0, 1.0)
        star_x = -0.35 * (1.0 - star_w) + 0.72 * star_w
        q.add(_SPH_140 * 0.12 + np.array([star_x, 2.08, 0.18]), _SPH_140, (0.75, 1.0, 1.0), STAR, shine=1.0)
        ray_u = np.linspace(0.0, 1.0, 64)
        q.add(np.column_stack([np.full_like(ray_u, star_x), 2.08 * (1.0 - ray_u) + 0.68 * ray_u, np.full_like(ray_u, 0.22)]), [0, 0, 1], (0.45, 0.98, 1.00), BEAM, shine=0.95)

        magi_bow = 0.32 * np.clip((local_t - 2.4) / 1.1, 0.0, 1.0)
        magi_vo = (vo_val if active_speaker == "3 WISE MEN" else 0.0) if active_speaker is not None else (vo_val if local_t >= 2.35 else 0.0)
        magi_walk = t * 8.5 if local_t < 2.4 else 0.0
        magi_dx = 0.22 * np.clip(local_t / 2.4, 0.0, 1.0)
        magi_list = [
            (-0.62 + magi_dx, 0.36, 1.14, (1.00, 0.82, 0.22), (0.98, 0.20, 0.38)),
            (-0.24 + magi_dx, 0.46, 1.08, (0.20, 0.78, 1.00), (0.40, 0.98, 1.00)),
            ( 0.12 + magi_dx, 0.52, 1.04, (0.96, 0.22, 0.42), (1.00, 0.88, 0.26)),
        ]
        u_c, v_c = np.meshgrid(np.linspace(-0.09, 0.09, 14), np.linspace(0.0, 0.16, 14))
        for mx, mz, mh, r_col, ch_col in magi_list:
            add_anatomical_human(
                q, mx, 0.0, mz, height=mh, robe_col=r_col,
                has_beard=True, has_crown=True, pose="prayer", bow_pitch=magi_bow, walk_phase=magi_walk, speaking_vo=magi_vo, facing_x=0.32
            )
            q.add(np.column_stack([mx + 0.18 + u_c.ravel(), v_c.ravel(), np.full(u_c.size, mz + 0.12)]), [0, 0.4, 0.9], ch_col, CHEST, shine=0.82)
            q.add(np.column_stack([mx + 0.18 + u_c.ravel(), np.full(u_c.size, 0.17), np.full(u_c.size, mz + 0.12)]), [0, 1, 0], (1.0, 0.92, 0.36), GOLD, shine=0.95)

        sm_u = np.linspace(0.0, 1.0, 90)
        sm_a = sm_u * TAU * 3.0 - t * 4.5
        q.add(np.column_stack([-0.06 + magi_dx + 0.06 * sm_u * np.cos(sm_a), 0.20 + 0.75 * sm_u, 0.58 + 0.06 * sm_u * np.sin(sm_a)]), [0, 1, 0], (0.55, 0.98, 1.00), BEAM, shine=0.9)

    # =========================================================================
    # SCENE 5 (32-40s): ESCAPE TO EGYPT & RETURN TO NAZARETH (Matthew 2:13-23)
    # =========================================================================
    else:
        # Background Pyramids pushed back to z = -0.75 with deeper bronze-amber tone so foreground Caravan pops!
        for px_p, pz_p, pw_p, ph_p in [(-0.88, -0.75, 0.68, 1.25), (-0.08, -0.88, 0.84, 1.52), (0.76, -0.75, 0.62, 1.12)]:
            for side_s in (-1.0, 1.0):
                px_f = px_p + side_s * (1.0 - _PYR_UF) * pw_p * 0.5 * (1.0 + _PYR_VF) * 0.5
                pz_f = pz_p + (1.0 - _PYR_UF) * pw_p * (1.0 - np.abs(_PYR_VF)) * 0.5
                py_f = _PYR_UF * ph_p
                pnrm = unit([side_s * 0.65, 0.55, 0.52])
                q.add(np.column_stack([px_f, py_f, pz_f]), pnrm, (0.72, 0.52, 0.18), PYRAMID, shine=0.45)

        ang_vo = (vo_val if active_speaker in ("ANGEL", "ANGEL HOST") else 0.0) if active_speaker is not None else (vo_val if local_t < 2.75 else 0.0)
        add_anatomical_human(q, -0.15, 1.38 + 0.04 * np.sin(t * 4.0), 0.05, height=0.82, robe_col=(0.55, 1.00, 1.00), pose="herald", speaking_vo=ang_vo)
        add_anatomical_avian_wings(q, -0.15, 1.96, 0.05, span=0.60, height=0.52, flap_angle=0.40 * np.sin(t * 6.5), col=(0.65, 1.00, 1.00))

        caravan_x = -0.52 + 0.96 * u_prog
        walk_ph = t * 9.5
        jos_vo = (vo_val if active_speaker == "JOSEPH" else 0.0) if active_speaker is not None else (vo_val if local_t >= 2.75 else 0.0)

        add_anatomical_human(
            q, caravan_x + 0.46, 0.0, 0.48, height=1.14, robe_col=(0.98, 0.76, 0.34), mantle_col=(1.0, 0.92, 0.55),
            has_beard=True, has_veil=True, pose="walk", walk_phase=walk_ph, speaking_vo=jos_vo, staff_side=1, facing_x=0.38
        )

        dk_x, dk_z = caravan_x - 0.14, 0.50
        add_anatomical_donkey(q, dk_x, 0.0, dk_z, scale=1.18, walk_phase=walk_ph)

        dk_bob = 0.018 * abs(np.sin(walk_ph * 2.0))
        add_anatomical_human(
            q, dk_x - 0.04, 0.40 + dk_bob, dk_z, height=0.82, robe_col=(0.18, 0.86, 1.00), mantle_col=(0.95, 0.98, 1.00),
            is_female=True, has_veil=True, pose="prayer", facing_x=0.32
        )
        q.add(_SPH_64 * 0.072 + np.array([dk_x + 0.08, 0.86 + dk_bob, dk_z + 0.10]), _SPH_64, (1.0, 0.98, 0.75), STAR, shine=1.0)

    return q.done(), sc_idx, local_t


def render_frame(bg_stars, t: float, width: int = 154, height: int = 96, style_mode: str = SELECTED_SUBTITLE_STYLE, forced_scene: int = 0, vo_val: float = 0.5, sfx_val: float = 0.4):
    (P_act, N_act, C_act, K_act, SH_act), sc_idx, local_t = build_scene_geometry(t, vo_val, sfx_val, forced_scene)
    sc_meta = DRAMA_SCENES[sc_idx - 1]
    sc_title = sc_meta[3]
    sc_sfx_desc = sc_meta[5]

    cam_az_deg = -10.0 + 20.0 * (local_t / 5.0) + 2.5 * np.sin(t * 1.8)
    theta = np.deg2rad(cam_az_deg)
    ca, sa = np.cos(theta), np.sin(theta)
    rot_m = np.array([[ca, 0.0, sa], [0.0, 1.0, 0.0], [-sa, 0.0, ca]])

    Y_orig = P_act[:, 1].copy()
    R_orig = np.sqrt(P_act[:, 0] ** 2 + P_act[:, 2] ** 2)
    P_rot = P_act @ rot_m.T
    N_rot = N_act @ rot_m.T

    lidar_scan_y = -0.05 + ((t * 1.55) % 2.35)
    lidar_ring_r = (t * 1.40) % 1.75
    beam_hit = np.exp(-((Y_orig - lidar_scan_y) / 0.075) ** 2)
    ring_hit = np.where(K_act == GROUND, np.exp(-((R_orig - lidar_ring_r) / 0.08) ** 2), 0.0)
    scan_hit = np.maximum(beam_hit, ring_hit)

    C_mod = C_act.copy()
    m_scan = scan_hit > 0.25
    if np.any(m_scan):
        sh_w = (scan_hit[m_scan] * 0.68)[:, None]
        C_mod[m_scan] = C_mod[m_scan] * (1.0 - sh_w) + np.array([0.35, 1.0, 1.0]) * sh_w

    # Close-Up Cinema Framing (cam_dist = 2.62, cam_y = 0.94) so figures fill the stage in HD
    cam_y = 0.94
    cam_dist = 2.62 - 0.08 * sfx_val
    pitch = np.deg2rad(5.0)
    cp, sp = np.cos(pitch), np.sin(pitch)
    pitch_m = np.array([[1.0, 0.0, 0.0], [0.0, cp, -sp], [0.0, sp, cp]])

    P_cam = (P_rot - np.array([0.0, cam_y, 0.0])) @ pitch_m.T
    N_cam = N_rot @ pitch_m.T

    z_depth = cam_dist - P_cam[:, 2]
    valid = z_depth > 0.35
    fov = min(width * 0.50, height * 0.96)
    px = (width * 0.5 + (P_cam[:, 0] / z_depth) * fov * 1.68).astype(np.int32)
    py = (height * 0.60 - (P_cam[:, 1] / z_depth) * fov).astype(np.int32)
    in_b = valid & (px >= 0) & (px < width) & (py >= 0) & (py < height)

    light_dir = unit(np.array([0.42, 0.68, 0.60]))
    half_dir = unit(light_dir + np.array([0.0, 0.0, 1.0]))
    ndotl = np.clip(N_cam @ light_dir, 0.0, 1.0)
    spec = np.clip(N_cam @ half_dir, 0.0, 1.0) ** 14
    # Fresnel Silhouette Rim-Lighting ((1 - N_z)^2.2) + Atmospheric Depth Fog
    fresnel_rim = np.where(K_act != GROUND, (1.0 - np.clip(np.abs(N_cam[:, 2]), 0.0, 1.0)) ** 2.2, 0.0)
    depth_fog = np.clip(np.exp(-0.38 * np.maximum(0.0, z_depth - 2.35)), 0.32, 1.0)

    lum = np.clip((0.30 + 0.65 * ndotl + SH_act * (0.48 * spec) + 0.42 * fresnel_rim + 0.16 * vo_val + 0.40 * scan_hit) * depth_fog, 0.0, 1.0)

    is_star = (K_act == STAR) | (K_act == BEAM)
    lum[is_star] = 0.99
    rgb = np.clip((C_mod * (0.52 + 0.68 * lum[:, None]) + np.array([0.22, 0.92, 1.0])[None, :] * (fresnel_rim[:, None] * 0.28)) * depth_fog[:, None], 0.0, 1.0)

    max_idx = np.where((K_act == GOLD) | (K_act == WING) | (K_act == SKIN) | (fresnel_rim > 0.55), 8, 7)
    ramp_idx = np.minimum(max_idx, np.maximum(1, (lum * (max_idx + 0.6)).astype(np.int32)))
    chars = ASCII_RAMP[ramp_idx]
    chars[K_act == STAR] = "@"
    chars[K_act == BEAM] = "*"

    char_buf = np.full((height, width), " ", dtype="<U1")
    rgb_buf = np.zeros((height, width, 3), dtype=np.uint8)

    for sx, sy, sch, s_ph in bg_stars:
        ix, iy = int(sx * width), int(sy * (height * 0.48))
        if 0 <= ix < width and 0 <= iy < height:
            tw = int(min(255, (120 + 95 * np.sin(2.5 * t + s_ph)) * (1.0 + 0.3 * sfx_val)))
            char_buf[iy, ix] = sch
            rgb_buf[iy, ix] = (int(tw * 0.65), tw, min(255, tw + 35))

    z_sort = z_depth.copy()
    z_sort[(K_act != GROUND) & (K_act != ARCH) & (K_act != PYRAMID)] -= 0.25
    idx = np.flatnonzero(in_b)
    order = idx[np.argsort(z_sort[idx])[::-1]]
    py_o = py[order]
    px_o = px[order]
    char_buf[py_o, px_o] = chars[order]
    rgb_buf[py_o, px_o] = (rgb[order] * 255).astype(np.uint8)

    def put_text(r, c0, txt, col=(215, 220, 228)):
        if 0 <= r < height:
            for i, ch in enumerate(txt):
                if 0 <= c0 + i < width:
                    char_buf[r, c0 + i] = ch
                    rgb_buf[r, c0 + i] = col

    speaker, spoken_line = sc_meta[4][0][2], sc_meta[4][0][3]
    for t0_l, t1_l, spk_l, txt_l in sc_meta[4]:
        if (t % 40.0) >= t0_l:
            speaker, spoken_line = spk_l, txt_l

    base_row = 2 if style_mode == "cinema_top" else (int(height * 0.20) if style_mode == "cipher_mid" else height - 9)
    put_text(base_row - 1, max(2, (width - len(sc_title)) // 2), sc_title, (255, 229, 143))
    full_vo = f"[{speaker}]: \"{spoken_line}\""
    put_text(base_row, max(2, (width - len(full_vo)) // 2), full_vo, (224, 255, 255))
    put_text(base_row + 1, max(2, (width - len(sc_sfx_desc)) // 2), sc_sfx_desc, (126, 249, 255))

    returns_count = int(np.count_nonzero(char_buf != " "))
    put_text(height - 4, 2, f"CHRISTMAS DRAMA · SCENE {sc_idx}/5 · ULTRA-HD FRESNEL LIDAR", (0, 245, 255))
    put_text(height - 3, 2, f"camera {cam_az_deg:+06.2f}°   speaker {speaker}", (201, 209, 217))
    put_text(height - 2, 2, f"returns {returns_count:,}", (126, 249, 255))

    out = ["\x1b[H"]
    for r in range(height):
        row_c = char_buf[r]
        row_rgb = rgb_buf[r]
        line = []
        last = None
        for c in range(width):
            ch = row_c[c]
            if ch == " ":
                line.append(" ")
            else:
                rgb_t = (int(row_rgb[c, 0]), int(row_rgb[c, 1]), int(row_rgb[c, 2]))
                bg_r, bg_g, bg_b = rgb_t[0] // 5, rgb_t[1] // 5, rgb_t[2] // 5
                if rgb_t != last:
                    line.append(f"\x1b[48;2;{bg_r};{bg_g};{bg_b}m\x1b[38;2;{rgb_t[0]};{rgb_t[1]};{rgb_t[2]}m{ch}")
                    last = rgb_t
                else:
                    line.append(ch)
        out.append("".join(line) + "\x1b[0m")
    return "\n".join(out), cam_az_deg, returns_count


def main():
    parser = argparse.ArgumentParser(description="christmas_drama_lidar.py — Ultra-HD 5-Scene Anatomical 3D LiDAR ASCII Christmas Drama")
    parser.add_argument("--fps", type=int, default=30)
    parser.add_argument("--duration", type=float, default=0.0)
    parser.add_argument("--width", type=int, default=154)
    parser.add_argument("--height", type=int, default=96)
    parser.add_argument("--scene", type=int, default=0, choices=[0, 1, 2, 3, 4, 5])
    args = parser.parse_args()

    rng_bg = np.random.default_rng(42)
    bg_stars = [(rng_bg.random(), rng_bg.random(), rng_bg.choice([".", "*", "+"]), rng_bg.uniform(0, TAU)) for _ in range(110)]

    dt = 1.0 / max(1, args.fps)
    t0 = time.perf_counter()
    sys.stdout.write("\x1b[?25l\x1b[2J")
    sys.stdout.flush()
    try:
        ts = shutil.get_terminal_size((154, 96))
        w = args.width if args.width > 0 else max(80, ts.columns)
        h = args.height if args.height > 0 else max(40, ts.lines - 1)
        while True:
            now = time.perf_counter()
            t = now - t0
            if args.duration > 0 and t >= args.duration:
                break
            frame, _, _ = render_frame(bg_stars, t, w, h, forced_scene=args.scene)
            sys.stdout.write(frame)
            sys.stdout.flush()
            rem = dt - (time.perf_counter() - now)
            if rem > 0:
                time.sleep(rem)
    except KeyboardInterrupt:
        pass
    finally:
        sys.stdout.write("\x1b[0m\x1b[?25h\n")
        sys.stdout.flush()


if __name__ == "__main__":
    main()