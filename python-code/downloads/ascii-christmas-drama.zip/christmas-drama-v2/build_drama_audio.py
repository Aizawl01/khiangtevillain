"""Assemble approved Gemini takes and measured dialogue cues; never substitute another voice."""
import argparse
import json
import os
from pathlib import Path
import numpy as np
import soundfile as sf


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    root = Path(__file__).resolve().parent
    args = parser.parse_args()
    cast_path = root/'cast_gemini.json'
    if not cast_path.is_file():
        parser.error('Generate and approve the Gemini takes first; cast_gemini.json is missing.')
    cast = json.loads(cast_path.read_text(encoding='utf-8'))
    assets = root/'voices'
    assets.mkdir(exist_ok=True)
    clips = []
    sr = 24000
    for line in cast:
        path = root/'gemini-takes'/f"{line['id']}.wav"
        if not path.is_file():
            raise FileNotFoundError(f'Approved voice take is missing: {path}')
        samples, sample_rate = sf.read(path, dtype='float32')
        if samples.ndim == 1:
            samples -= samples.mean()
            samples *= 0.72/max(float(np.max(np.abs(samples))), 0.001)
        if sample_rate != sr or samples.ndim != 1 or len(samples) == 0:
            raise ValueError(f'Unexpected audio format: {path.name}')
        clips.append((line, samples))
        print(f"{line['speaker']}: {len(samples)/sr:.2f}s ({line['voice']})", flush=True)
    scenes, lines = [], []
    cursor = 0.0
    for scene in sorted({line['scene'] for line, _ in clips}):
        scene_start = cursor
        cursor += .4
        for line, samples in [item for item in clips if item[0]['scene'] == scene]:
            active = np.flatnonzero(np.abs(samples) > .012)
            start = cursor
            duration = len(samples)/sr
            lines.append(dict(line, file=f'gemini-takes/{line["id"]}.wav',
                              audio_start=start, start=start+int(active[0])/sr if len(active) else start,
                              end=start+(int(active[-1])+1)/sr if len(active) else start+duration,
                              duration=duration))
            cursor += duration+.4
        cursor += .4
        scenes.append(dict(id=scene, start=scene_start, end=cursor))
    duration = cursor+.8
    voice = np.zeros(round(duration*sr), dtype=np.float32)
    for meta, (_, samples) in zip(lines, clips):
        first = round(meta['audio_start']*sr)
        voice[first:first+len(samples)] += samples
    sf.write(root/'dialogue.wav', voice, sr, subtype='PCM_16')
    ambience = np.zeros_like(voice)
    chords = [(130.81,164.81,196), (146.83,174.61,220), (174.61,220,261.63),
              (110,130.81,164.81), (130.81,164.81,196)]
    for scene, chord in zip(scenes, chords):
        a, b = round(scene['start']*sr), round(scene['end']*sr)
        t = np.arange(b-a)/sr
        envelope = np.minimum(1,t/1.2)*np.minimum(1,(len(t)/sr-t)/1.2)
        pad = sum(np.sin(2*np.pi*f*t) for f in chord)/len(chord)
        ambience[a:b] += .023*pad*envelope
        sweep_t = np.arange(min(round(.7*sr), b-a))/sr
        sweep = .012*np.sin(2*np.pi*(900*sweep_t-450*sweep_t**2)) * np.sin(np.pi*sweep_t/.7)**2
        ambience[a:a+len(sweep)] += sweep
    # Keep the atmosphere below dialogue rather than compressing the voices into it.
    mix = voice + ambience*.45
    peak = float(np.max(np.abs(mix)))
    if peak>.88:
        mix *= .88/peak
    sf.write(root/'soundtrack.wav', np.column_stack([mix,mix]), sr, subtype='PCM_16')
    hop = sr//30
    rms = [float(np.sqrt(np.mean(voice[i:i+hop]**2))) for i in range(0,len(voice),hop)]
    scale = max(max(rms),.001)
    data = dict(duration=duration, fps=30, scenes=scenes, lines=lines,
                voice_envelope=[min(1,v/scale) for v in rms],
                timing='Dialogue cue bounds measured from generated waveform; captions show whole lines, not estimated karaoke.',
                voice_credit='Gemini 3.8 Flash TTS; directed voices listed in cast_gemini.json')
    (root/'timeline.json').write_text(json.dumps(data,indent=2),encoding='utf-8')
    print(f'Soundtrack and measured dialogue timeline: {duration:.2f}s',flush=True)


if __name__ == '__main__':
    main()
