"""Render the revised ASCII drama from approved audio and measured scene cues."""
import argparse
import ast
import json
import math
from pathlib import Path
import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter
from christmas_drama_lidar import build_scene_geometry, GROUND, STAR, BEAM, GOLD, WING

ROOT = Path(__file__).resolve().parent
W, H, FPS = 1080, 1920, 30
COLS, ROWS, CW, CH = 232, 144, 4, 6
CYAN, WHITE, GOLD_TEXT = (100, 221, 239), (235, 241, 244), (245, 210, 136)
TITLES = ['THE ANNUNCIATION', "JOSEPH'S DREAM", 'BETHLEHEM', 'THE GUIDING STAR', 'THE JOURNEY HOME']


def font(size, mono=False):
    candidates = ([ROOT/'DejaVuSansMono.ttf', Path('C:/Windows/Fonts/consola.ttf'),
                   Path('/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf')] if mono else
                  [ROOT/'DejaVuSans.ttf', Path('C:/Windows/Fonts/segoeui.ttf'),
                   Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')])
    for path in candidates:
        if path.is_file():
            return ImageFont.truetype(str(path), size)
    return ImageFont.load_default(size=size)


def wrap(text, face, max_width):
    rows, current = [], ''
    for word in text.split():
        candidate = f'{current} {word}'.strip()
        if current and face.getlength(candidate) > max_width:
            rows.append(current)
            current = word
        else:
            current = candidate
    if current:
        rows.append(current)
    return rows


class Renderer:
    def __init__(self, timeline):
        self.timeline = timeline
        self.grid_font = font(8, True)
        self.label_font, self.title_font = font(22, True), font(34)
        self.caption_font, self.code_font = font(40), font(22, True)
        atlas = np.zeros((128, CH, CW), dtype=np.float32)
        for c in range(32, 127):
            image = Image.new('L', (CW, CH))
            ImageDraw.Draw(image).text((0,-1), chr(c), font=self.grid_font, fill=255)
            atlas[c] = np.asarray(image)/255
        self.atlas = atlas
        source = (ROOT/'christmas_drama_lidar.py').read_text(encoding='utf-8').splitlines()
        tree = ast.parse('\n'.join(source))
        self.code = []
        for scene_id in range(1,6):
            branch = next(n for n in ast.walk(tree) if isinstance(n,ast.If)
                          and isinstance(n.test,ast.Compare) and isinstance(n.test.left,ast.Name)
                          and n.test.left.id=='sc_idx' and isinstance(n.test.comparators[0],ast.Constant)
                          and n.test.comparators[0].value==min(scene_id,4))
            body = branch.orelse if scene_id==5 else branch.body
            first, last = body[0].lineno, body[-1].end_lineno
            self.code.append([(i+1,source[i]) for i in range(first-1,last)])
        rng = np.random.default_rng(42)
        self.stars = list(zip(rng.integers(15,COLS-15,85),rng.integers(4,ROWS//2,85),rng.random(85)))
        icon_path = ROOT.parent/'python_icon.png'
        self.icon = Image.open(icon_path).convert('RGBA').resize((24,24)) if icon_path.is_file() else None
        for line in timeline['lines']:
            assert len(wrap(line['text'],self.caption_font,880)) <= 2, line['id']

    def frame(self, t):
        data = self.timeline
        scene = next((s for s in data['scenes'] if s['start']<=t<s['end']),data['scenes'][-1])
        index = scene['id']-1
        progress = np.clip((t-scene['start'])/(scene['end']-scene['start']),0,1)
        source_t = index*8 + min(7.999,progress*8)
        line = next((l for l in data['lines'] if l['scene']==scene['id'] and l['start']<=t<=l['end']+.2),None)
        speaker = line['speaker'] if line else ''
        vi = min(len(data['voice_envelope'])-1,max(0,int(t*30)))
        voice = data['voice_envelope'][vi]
        (points,normals,colours,kinds,shine),_,_ = build_scene_geometry(source_t,voice,0,active_speaker=speaker)
        # Establish the stage, then gently favour the responding speaker.
        focus = {'GABRIEL':-.15,'MARY':.22,'JOSEPH':.08,'KING HEROD':-.22,'3 WISE MEN':.12,
                 'ANGEL HOST':0,'SHEPHERDS':-.22,'ANGEL':0}.get(speaker,0)
        if line:
            previous = next((l for l in data['lines'] if l['scene']==scene['id'] and l['start']<line['start']),None)
            if previous:
                prior = {'GABRIEL':-.15,'MARY':.22,'JOSEPH':.08,'KING HEROD':-.22,'3 WISE MEN':.12,
                         'ANGEL HOST':0,'SHEPHERDS':-.22,'ANGEL':0}.get(previous['speaker'],0)
                blend = float(np.clip((t-line['start'])/.9,0,1));blend=blend*blend*(3-2*blend)
                focus = prior+(focus-prior)*blend
        hold = np.clip((t-scene['start']-1.0)/1.4,0,1)
        hold = hold*hold*(3-2*hold)
        focus *= hold
        if index==2 and progress>.55:
            focus = .24*hold
        angle = math.radians(-5+10*progress)
        c,s = math.cos(angle),math.sin(angle)
        rotation = np.array([[c,0,s],[0,1,0],[-s,0,c]])
        p = points@rotation.T-np.array([focus,.95,0])
        n = normals@rotation.T
        distance = 2.95-.14*hold
        z = distance-p[:,2]
        x = (COLS*.5+p[:,0]/np.maximum(z,.1)*112*1.68).astype(int)
        y = (ROWS*.57-p[:,1]/np.maximum(z,.1)*112).astype(int)
        valid = (z>.35)&(x>=0)&(x<COLS)&(y>=0)&(y<ROWS)
        light = np.array([.35,.7,.62]);light/=np.linalg.norm(light)
        diffuse = np.maximum(0,n@light)
        rim = (1-np.clip(np.abs(n[:,2]),0,1))**2
        fog = np.clip(np.exp(-.32*np.maximum(z-2.4,0)),.35,1)
        scan = np.exp(-((points[:,1]-(-.1+(source_t*.5)%2.3))/.045)**2)
        lum = np.clip((.32+.6*diffuse+.14*rim+.12*scan)*fog,.1,1)
        lum[(kinds==STAR)|(kinds==BEAM)] = 1
        rgb = np.clip(colours*(.42+.63*lum[:,None])*fog[:,None],0,1)
        rgb[kinds==GROUND] *= .38
        ramp = np.array([ord(v) for v in ' .:-=+*#%@'])
        codes = ramp[np.clip((lum*8).astype(int),1,9)]
        codes[kinds==STAR] = ord('@')
        grid = np.full((ROWS,COLS),32,dtype=int)
        rgb_grid = np.zeros((ROWS,COLS,3),dtype=np.float32)
        for sx,sy,phase in self.stars:
            grid[sy,sx] = ord('.')
            rgb_grid[sy,sx] = (.10,.18,.24)
        order = np.flatnonzero(valid)
        order = order[np.argsort(z[order])[::-1]]
        # Nearest samples win each cell, including collisions inside one surface.
        flat = y[order]*COLS+x[order]
        _, reverse_index = np.unique(flat[::-1],return_index=True)
        order = order[len(order)-1-reverse_index]
        grid[y[order],x[order]] = codes[order]
        rgb_grid[y[order],x[order]] = rgb[order]
        mask = np.maximum(self.atlas[grid],(grid!=32)[...,None,None]*.10)
        cells = mask[...,None]*rgb_grid[:,:,None,None,:]
        pixels = (np.clip(cells.transpose(0,2,1,3,4).reshape(ROWS*CH,COLS*CW,3),0,1)*255).astype('uint8')
        stage = Image.fromarray(np.maximum(pixels,np.array([4,9,15],dtype='uint8')))
        highlight = stage.point(lambda v: max(0,v-175)*2).filter(ImageFilter.GaussianBlur(4))
        stage = Image.fromarray(np.minimum(255,np.asarray(stage,dtype=np.uint16)+np.asarray(highlight,dtype=np.uint16)//3).astype('uint8'))
        picture = Image.new('RGB',(W,H),(4,9,15))
        picture.paste(stage,((W-stage.width)//2,350))
        draw = ImageDraw.Draw(picture)
        draw.text((72,96),TITLES[index],font=self.title_font,fill=GOLD_TEXT)
        draw.text((810,106),f'{scene["id"]:02d} / 05',font=self.label_font,fill=CYAN)
        if line:
            draw.text((72,158),speaker,font=self.label_font,fill=CYAN)
            for row,text in enumerate(wrap(line['text'],self.caption_font,880)):
                draw.text((72,200+row*52),text,font=self.caption_font,fill=WHITE)
        else:
            draw.text((72,178),'LUKE 1–2  /  MATTHEW 1–2',font=self.label_font,fill=(116,139,150))
        draw.line((72,308,960,308),fill=(27,57,66),width=1)
        draw.text((72,1254),'ASCII CINEMA  /  CHRISTMAS',font=self.label_font,fill=(126,166,177))
        # A quiet progress rail takes the place of the noisy collection of HUD labels.
        draw.line((72,1300,960,1300),fill=(25,48,60),width=3)
        draw.line((72,1300,72+round(888*np.clip(t/data['duration'],0,1)),1300),fill=CYAN,width=3)
        draw.rounded_rectangle((48,1340,1008,1780),radius=14,fill=(10,15,23),outline=(35,63,76))
        draw.line((48,1390,1008,1390),fill=(35,63,76))
        if self.icon:
            picture.paste(self.icon,(70,1353),self.icon)
        draw.text((108,1350),'christmas_drama_lidar.py',font=self.label_font,fill=WHITE)
        rows = self.code[index]
        start = min(max(0,len(rows)-11),int(progress*max(0,len(rows)-11)))
        for row,(number,text) in enumerate(rows[start:start+11]):
            yy = 1410+row*30
            draw.text((68,yy),str(number),font=self.code_font,fill=(94,113,128))
            while self.code_font.getlength(text)>820:
                text=text[:-2]
            colour = (120,168,206) if text.lstrip().startswith(('def ','for ','if ','return ')) else (169,193,204)
            draw.text((126,yy),text,font=self.code_font,fill=colour)
        # Fade to black only after the final line and its hold have completed.
        if t>data['duration']-.7:
            picture = Image.blend(picture,Image.new('RGB',(W,H)),float(np.clip((t-data['duration']+.7)/.7,0,1)))
        return picture


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=ROOT/'Christmas_Drama_V2_Picture.mp4')
    parser.add_argument('--stills',action='store_true')
    args = parser.parse_args()
    timeline = json.loads((ROOT/'timeline.json').read_text(encoding='utf-8'))
    renderer = Renderer(timeline)
    if args.stills:
        folder = ROOT/'previews';folder.mkdir(exist_ok=True)
        for scene in timeline['scenes']:
            for fraction in (.25,.7):
                t = scene['start']+(scene['end']-scene['start'])*fraction
                renderer.frame(t).save(folder/f'scene_{scene["id"]}_{int(fraction*100)}.png')
        return
    writer = cv2.VideoWriter(str(args.output),cv2.VideoWriter_fourcc(*'mp4v'),FPS,(W,H))
    if not writer.isOpened():
        raise RuntimeError('Could not open the picture encoder')
    count = math.ceil(timeline['duration']*FPS)
    try:
        for frame in range(count):
            image = renderer.frame(frame/FPS)
            writer.write(cv2.cvtColor(np.asarray(image),cv2.COLOR_RGB2BGR))
            if frame%150==0:
                print(f'{frame}/{count}',flush=True)
    finally:
        writer.release()
    print(f'Rendered {count} picture frames. Mux soundtrack.wav and export H.264 for delivery.',flush=True)


if __name__ == '__main__':
    main()
