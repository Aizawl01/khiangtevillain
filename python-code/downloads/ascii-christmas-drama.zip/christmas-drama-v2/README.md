# Christmas Drama — Gemini revision

The finished film is `Christmas_Drama_V2_Gemini.mp4`: 1080 × 1920, 30 FPS, about 65 seconds. All ten original dialogue lines are retained. Scene lengths follow the approved Gemini takes instead of forcing each scene to eight seconds.

The original files in Downloads were preserved. This project is separate from the published Krismas tree visualizer.

## What changed

- Directed Gemini 3.8 Flash TTS voices: Charon, Aoede, Puck, Orus and Fenrir. No Flite fallback, pitch shifting or added vocal echo.
- Larger, wrapped dialogue and quieter HUD treatment.
- Measured dialogue cue bounds, a real voice-amplitude envelope and speaker highlights driven by the selected dialogue cue.
- Gentle speaker framing and source animation retimed to the new scene schedule.
- Code panel shows the actual geometry source for the current scene, with real line numbers.
- H.264 / AAC stereo / BT.709 delivery, with approximately −15 LUFS and −1.5 dBTP.

## Files and rebuilding

Install Python 3.10+ and the requirements:

```powershell
python -m pip install -r requirements.txt
```

`gemini-takes/` contains the approved voice recordings. `cast_gemini.json` stores the dialogue, voice names and delivery directions. Playback and rendering do not call any external service.

```powershell
python build_drama_audio.py
python render_christmas_drama_mp4.py --stills
python render_christmas_drama_mp4.py
```

The renderer writes the silent picture master `Christmas_Drama_V2_Picture.mp4`. `soundtrack.wav` contains the voice and quiet atmospheric bed. `soundtrack_final.wav` is the normalized mix used in the delivered film.

To mux and encode a rebuilt picture with FFmpeg installed:

```powershell
ffmpeg -i Christmas_Drama_V2_Picture.mp4 -i soundtrack_final.wav -map 0:v:0 -map 1:a:0 -c:v libx264 -crf 18 -pix_fmt yuv420p -color_primaries bt709 -color_trc bt709 -colorspace bt709 -c:a aac -b:a 192k -ar 48000 -movflags +faststart Christmas_Drama_Rebuilt.mp4
```

If you changed the dialogue, regenerate and normalize the new soundtrack before muxing; the supplied normalized mix belongs to the supplied takes.

## Optional voice regeneration

The included takes require no API key to play. To generate replacements, configure your own `GEMINI_API_KEY` in the process environment, then:

```powershell
python generate_gemini_voices.py --line 01_1 --replace
python build_drama_audio.py
```

Generation uses Google's API quota. Existing takes are kept unless `--replace` is explicitly set. Failures stop generation rather than substituting another voice. No credential is included in these project files.

## Verification and limits

All 1,962 video frames decoded without errors. Format, aspect, colour tags, audio presence and delivery levels passed the export checks. Captions are burned in; a separate English SRT is also supplied.

Local speech recognition recovered all ten lines, with recognition ambiguities around “Behold” and the spelling of “Immanuel.” That is an automated check, not a human performance review.

Dialogue cue bounds are measured from each waveform, not manually verified word alignment. The actor geometry is stylized ASCII; it is not lip-synced facial animation. Final Instagram overlays vary by app version and caption length.
