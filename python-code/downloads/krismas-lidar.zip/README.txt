KHIANGTEVILLAIN AI — krismas-lidar

DESKTOP (Windows / macOS / Linux)
1. Extract the entire ZIP into one folder.
2. Install Python 3.10+ and VS Code with its Python extension.
3. Open the extracted folder in VS Code. In Terminal run:
   python -m pip install -r requirements.txt
4. Open krismasvisualizer_desktop.py and choose Run Python File.
   The original krismasvisualizer.py also runs directly as before.

ANDROID — EXPERIMENTAL / NOT TESTED ON A PHONE
1. Install Pydroid 3 from Google Play:
   https://play.google.com/store/apps/details?id=ru.iiec.pydroid3
2. Extract the entire ZIP using your phone file manager.
3. Use Pydroid's Pip package manager to install the packages in requirements.txt.
4. Open krismasvisualizer_android.py in Pydroid and tap Run.
5. Allow access to the extracted folder if requested. Keep all files together.

Android defaults: fit the available display, preserve the scene proportions,
15 FPS rendering. Audio timing remains tied to song playback, not frame count.
Optional terminal command (from the extracted folder):
python krismasvisualizer_android.py --width 0 --height 0 --fps 15
Zero width/height means use the available display size. FPS accepts 1–60.

Touch controls: Pause/Play, Replay, Exit.
Krismas also has Mode 1/2/3, drag rotation, Reset, and minus/plus zoom buttons.
Pinch zoom is not implemented. Android audio, fonts, speed and file access can
vary by phone and Pydroid build. Use desktop if the app errors or performs poorly.

FILES
krismasvisualizer.py: shared visual scene, also the standalone desktop script.
krismasvisualizer_desktop.py: desktop launcher.
krismasvisualizer_android.py: Android launcher.
mobile_controls.py: shared touch controls; keep beside the launchers.
nov christmas song mizo.mp3: matching song excerpt, included.
requirements.txt: dependencies. python_icon.png: Python icon.

The heart follows the 38-second excerpt; Christmas follows the 15-second excerpt.
Changing songs requires editing the built-in timing. These scripts do not
transcribe replacement songs automatically.

Portfolio: https://khiangtevillain.pages.dev/python-code/
