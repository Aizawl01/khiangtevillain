KHIANGTEVILLAIN AI — krismas-lidar

1. Install Python 3.10+ and VS Code with the Python extension.
2. Extract this ZIP. Open the extracted folder in VS Code.
3. Open Terminal > New Terminal and run:
   python -m pip install -r requirements.txt
   On Windows, if needed: py -m pip install -r requirements.txt
4. Put your local song excerpt in this folder, named exactly:
   nov christmas song mizo.mp3
5. Open krismasvisualizer.py, select the same Python interpreter, then Run Python File.

Controls: 1 / 2 / 3: lyric mode. Drag: rotate. Scroll: zoom. Space: pause. R: replay. Home: reset. Esc / close: exit.

Music is not included. The lyrics, chords and motion timing are built for the excerpt shown in the Reel (38 seconds for the heart; 15 seconds for Christmas). Replacing the song requires adjusting those timings; these scripts do not transcribe a new song automatically.

Desktop Python applications; these do not run in your phone browser.
If a package is missing, install it with the same Python selected in VS Code.
System fonts can look different between Windows, macOS and Linux.

Portfolio: https://aizawl01.github.io/khiangtevillain/
Instagram: https://www.instagram.com/khiangte.villain.ai/
YouTube: https://www.youtube.com/@khiangtevillainai/
