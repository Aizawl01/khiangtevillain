"""Touch controls shared by the experimental Android launchers."""
import argparse
import pygame


def launch(main):
    parser = argparse.ArgumentParser(description="Experimental Android visualizer")
    parser.add_argument('--width', type=int, default=0)
    parser.add_argument('--height', type=int, default=0)
    parser.add_argument('--fps', type=int, default=15)
    args = parser.parse_args()
    if args.width < 0 or args.height < 0 or not 1 <= args.fps <= 60:
        parser.error('width and height must be nonnegative; fps must be 1–60')
    main(mobile=True, width=args.width, height=args.height, fps=args.fps)


class TouchControls:
    def __init__(self, scene=False):
        self.scene = scene
        self.finger = None
        self.last = None
        self.buttons = []

    def layout(self, size):
        w, h = size
        self.bar_height = min(112, max(64, h // 10))
        labels = ['Play', 'Replay', 'Exit']
        if self.scene:
            labels = ['Play', 'Replay', 'Reset', '−', '+', 'Exit']
        self.buttons = [(label, pygame.Rect(i*w//len(labels), h-self.bar_height,
                        (i+1)*w//len(labels)-i*w//len(labels), self.bar_height))
                        for i, label in enumerate(labels)]

    def handle(self, event, size):
        self.layout(size)
        if event.type in (pygame.FINGERDOWN, pygame.FINGERMOTION, pygame.FINGERUP):
            pos = (event.x * size[0], event.y * size[1])
            if event.type == pygame.FINGERDOWN:
                if self.finger is not None:
                    return None
                self.finger = event.finger_id
                self.last = pos
                return self.hit(pos)
            if event.finger_id != self.finger:
                return None
            if event.type == pygame.FINGERUP:
                self.finger = self.last = None
                return None
            previous, self.last = self.last, pos
            if previous and pos[1] < size[1]-self.bar_height and previous[1] < size[1]-self.bar_height:
                return ('drag', pos[0]-previous[0], pos[1]-previous[1])
        elif event.type in (pygame.MOUSEBUTTONDOWN, pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION):
            if getattr(event, 'touch', False):
                return None
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                self.last = event.pos
                return self.hit(event.pos)
            if event.type == pygame.MOUSEBUTTONUP:
                self.last = None
            elif event.type == pygame.MOUSEMOTION and self.last is not None:
                previous, self.last = self.last, event.pos
                if event.pos[1] < size[1]-self.bar_height and previous[1] < size[1]-self.bar_height:
                    return ('drag', event.pos[0]-previous[0], event.pos[1]-previous[1])
        return None

    def hit(self, pos):
        return next((label for label, rect in self.buttons if rect.collidepoint(pos)), ('tap', pos))

    def draw(self, surface, paused):
        self.layout(surface.get_size())
        font = pygame.font.Font(None, max(18, min(32, surface.get_width()//20)))
        for label, rect in self.buttons:
            pygame.draw.rect(surface, (17, 26, 38), rect.inflate(-4, -6), border_radius=8)
            text = ('Play' if paused else 'Pause') if label == 'Play' else label
            glyph = font.render(text, True, (200, 235, 255))
            surface.blit(glyph, glyph.get_rect(center=rect.center))
