from lyricsvisualizer import main
from mobile_controls import launch

if __name__ == "__main__":
    launch(main)
